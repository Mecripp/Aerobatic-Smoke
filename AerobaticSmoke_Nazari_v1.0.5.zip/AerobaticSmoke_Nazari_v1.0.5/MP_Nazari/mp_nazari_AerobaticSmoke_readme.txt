
=======================================

AerobaticSmoke


=======================================



License:

Attribution 4.0 International (CC BY 4.0)


author: Nazari
contact: Nazari1382 on Official KerbalSpaceProgram.com forum 
also on reddit: Nazari1382

http://forum.kerbalspaceprogram.com/threads/79181-AerobaticSmoke






Additional credits:
sarbian, eggrobin (SmokeScreen)

SmokeScreen is an enhanced FX plugin by Sarian. Thread:
http://forum.kerbalspaceprogram.com/threads/71630-0-23-SmokeScreen-Extended-FX-plugin

Licence : Attribution 4.0 International (CC BY 4.0): http://creativecommons.org/licenses/by/4.0/


Source : https://github.com/sarbian/SmokeScreen/